package com.project.Telecom.Service;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.Telecom.Entity.Plan;
import com.project.Telecom.Entity.Recharge;
import com.project.Telecom.Entity.Status;
import com.project.Telecom.Entity.User;
import com.project.Telecom.Repository.PlanRepository;
import com.project.Telecom.Repository.RechargeRepository;
import com.project.Telecom.Repository.UserRepository;
@Service
public class RechargeService {
	@Autowired	
	    private final RechargeRepository rechargeRepository;
	    private final UserRepository userRepository;
	    private final PlanRepository planRepository;

	    public RechargeService(RechargeRepository rechargeRepository,
	                           UserRepository userRepository,
	                           PlanRepository planRepository) {
	        this.rechargeRepository = rechargeRepository;
	        this.userRepository = userRepository;
	        this.planRepository = planRepository;
	    }

	    public Recharge createRecharge(Long userId, Long planId) {
	        User user = userRepository.findById(userId)
	            .orElseThrow(() -> new RuntimeException("User not found"));
	        Plan plan = planRepository.findById(planId)
	            .orElseThrow(() -> new RuntimeException("Plan not found"));
	        System.out.println(user);
	        System.out.println(plan);
	        Recharge recharge = new Recharge();
	    //    recharge.setId(rechargeId);
	        recharge.setUser(user);
	        recharge.setPlan(plan);
	        recharge.setDate(new Date());
	        recharge.setAmount(plan.getPrice());
	        recharge.setStatus(Status.success);
	        System.out.println(user);
	        System.out.println(plan);
	        System.out.println(recharge);
	        return rechargeRepository.save(recharge);
	    }

	    public Optional<Recharge> getRechargeHistory(Long userId) {
	        return rechargeRepository.findById(userId);
	    }
	    public List<Recharge> getAllRecharges() {
	        return rechargeRepository.findAll();
	    }
	}

