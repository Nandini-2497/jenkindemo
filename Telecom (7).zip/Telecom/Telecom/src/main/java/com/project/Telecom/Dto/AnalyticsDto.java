package com.project.Telecom.Dto;

import java.util.Map;

public class AnalyticsDto {
	    private long totalRechargesToday;
	    private long newUsersToday;
	    private double revenueToday;
	    private Map<String, Long> topComplaints; // e.g., {"Network Issue": 5, "Billing": 3}
		@Override
		public String toString() {
			return "AnalyticsDto [totalRechargesToday=" + totalRechargesToday + ", newUsersToday=" + newUsersToday
					+ ", revenueToday=" + revenueToday + ", topComplaints=" + topComplaints + "]";
		}
		public long getTotalRechargesToday() {
			return totalRechargesToday;
		}
		public void setTotalRechargesToday(long totalRechargesToday) {
			this.totalRechargesToday = totalRechargesToday;
		}
		public long getNewUsersToday() {
			return newUsersToday;
		}
		public void setNewUsersToday(long newUsersToday) {
			this.newUsersToday = newUsersToday;
		}
		public double getRevenueToday() {
			return revenueToday;
		}
		public void setRevenueToday(double revenueToday) {
			this.revenueToday = revenueToday;
		}
		public Map<String, Long> getTopComplaints() {
			return topComplaints;
		}
		public void setTopComplaints(Map<String, Long> topComplaints) {
			this.topComplaints = topComplaints;
		}
		public AnalyticsDto(long totalRechargesToday, long newUsersToday, double revenueToday,
				Map<String, Long> topComplaints) {
			super();
			this.totalRechargesToday = totalRechargesToday;
			this.newUsersToday = newUsersToday;
			this.revenueToday = revenueToday;
			this.topComplaints = topComplaints;
		}
		public AnalyticsDto() {
		//	super();
			// TODO Auto-generated constructor stub
		}
	}


