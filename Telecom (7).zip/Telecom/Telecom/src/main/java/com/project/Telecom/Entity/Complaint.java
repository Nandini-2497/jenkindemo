package com.project.Telecom.Entity;

import java.time.LocalDateTime;



import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
@Entity
@Table

public class Complaint {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
		Long id;
		
		@Column(nullable=false)
	    String Title;
		@Column(nullable=false)
		String description;
		@Enumerated(EnumType.STRING)
		@Column(name="complaint_status",nullable=false)
		ComplaintStatus complaintStatus2;
		@Column(nullable=false)
		LocalDateTime Created_At;
		@Column(nullable=false)
		LocalDateTime resolved_At;
		@ManyToOne
		@JoinColumn(name="user_id")
		User user;
		public Long getId() {
			return id;
		}
		public void setId(Long id) {
			this.id = id;
		}
		public String getTitle() {
			return Title;
		}
		public void setTitle(String title) {
			this.Title = title;
		}
		public String getDescription() {
			return description;
		}
		public void setDescription(String description) {
			this.description = description;
		}
		public ComplaintStatus getComplaintStatus() {
			return complaintStatus2;
		}
		public void setComplaintStatus(ComplaintStatus complaintStatus) {
			this.complaintStatus2 = complaintStatus;
		}
		public LocalDateTime getCreated_At() {
			return Created_At;
		}
		public void setCreated_At(LocalDateTime created_At) {
			this.Created_At = created_At;
		}
		public LocalDateTime getResolved_At() {
			return resolved_At;
		}
		public void setResolved_At(LocalDateTime resolved_At) {
			this.resolved_At = resolved_At;
		}
		public User getUser() {
			return user;
		}
		public void setUser(User user) {
			this.user = user;
		}
		@Override
		public String toString() {
			return "Complaint [id=" + id + ", Title=" + Title + ", description=" + description + ", ComplaintStatus="
					+ complaintStatus2 + ", Created_At=" + Created_At + ", resolved_At=" + resolved_At + ", user=" + user
					+ "]";
		}
		public Complaint(Long id, String title, String description, ComplaintStatus complaintStatus, LocalDateTime created_At,
				LocalDateTime resolved_At, User user) {
			super();
			this.id = id;
			this.Title = title;
			this.description = description;
			this.complaintStatus2 = complaintStatus;
			this.Created_At = created_At;
			this.resolved_At = resolved_At;
			this.user = user;
		}
		public Complaint() {
			
		//	super();
			// TODO Auto-generated constructor stub
		}
		
}
		