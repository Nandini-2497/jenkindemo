package com.project.Telecom.Entity;

public enum ComplaintStatus {
	Open,Inprogress,Resolved;

}
