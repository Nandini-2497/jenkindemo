package com.project.Telecom.Dto;


import java.util.Date;

import com.project.Telecom.Entity.PlanType;
import com.project.Telecom.Entity.Status;

public class RechargeDto {
	Long id;
	String username;
	String planname;
	Date date;
	int amount;
	Status status;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPlanname() {
		return planname;
	}
	public void setPlanname(String planname) {
		this.planname = planname;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public Status getStatus() {
		return status;
	}
	public void setStatus(Status status) {
		this.status = status;
	}
	@Override
	public String toString() {
		return "RechargeDto [ username=" + username + ", planname=" + planname + ", date=" + date
				+ ", amount=" + amount + ", status=" + status + "]";
	}
	public RechargeDto(Long id, String username, String planname, Date date, int amount, Status status) {
		super();
		this.id = id;
		this.username = username;
		this.planname = planname;
		this.date = date;
		this.amount = amount;
		this.status = status;
	}
	public RechargeDto() {
	//	super();
		// TODO Auto-generated constructor stub
	}
	public RechargeDto(String name, String name2, PlanType type, int amount2, Date date2) {
		// TODO Auto-generated constructor stub
	}
	
	
	}
