package com.project.Telecom.Repository;


import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.project.Telecom.Entity.Complaint;
import com.project.Telecom.Entity.User;
@Repository
@EnableJpaRepositories
public interface ComplaintRepository  extends CrudRepository< Complaint ,Long>,JpaRepository<Complaint,Long>{

	 List<Complaint> findByUserId(Long userId);

	 List<Complaint> findByUser(User user);
	
}
