package com.project.Telecom.Service;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.Telecom.Dto.AnalyticsDto;
import com.project.Telecom.Repository.ComplaintRepository;
import com.project.Telecom.Repository.RechargeRepository;
import com.project.Telecom.Repository.UserRepository;
@Service
public class AnalyticsService {
	@Autowired
	private final RechargeRepository rechargeRepository;
    private final UserRepository userRepository;
    private final ComplaintRepository complaintRepository;

    public AnalyticsService(RechargeRepository rechargeRepository,
                            UserRepository userRepository,
                            ComplaintRepository complaintRepository) {
        this.rechargeRepository = rechargeRepository;
        this.userRepository = userRepository;
        this.complaintRepository = complaintRepository;
    }

//    public AnalyticsDto getDailySummary() {
//        long totalRecharges = rechargeRepository.countTodayRecharges();
//        Double revenue = rechargeRepository.sumTodayRevenue();
//        long newUsers = userRepository.countTodayUsers();
//        List<Object[]> complaints = complaintRepository.findTopComplaintTypes();
//
//        Map<String, Long> topComplaints = new LinkedHashMap<>();
//        for (Object[] row : complaints) {
//            topComplaints.put((String) row[0], (Long) row[1]);
//        }
//
//        return new AnalyticsDto
//        		(
//                totalRecharges,
//                newUsers,
//                revenue != null ? revenue : 0.0,
//                topComplaints
//        );
    }



