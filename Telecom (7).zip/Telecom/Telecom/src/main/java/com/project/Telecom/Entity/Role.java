package com.project.Telecom.Entity;

public enum Role {
	user,admin;

}
