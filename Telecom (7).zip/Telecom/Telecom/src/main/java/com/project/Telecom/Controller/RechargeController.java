package com.project.Telecom.Controller;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.project.Telecom.Dto.RechargeDto;
import com.project.Telecom.Entity.Recharge;
import com.project.Telecom.Service.RechargeService;

@RestController
@RequestMapping("/api/recharges")
public class RechargeController {

    private final RechargeService rechargeService;

    public RechargeController(RechargeService rechargeService) {
        this.rechargeService = rechargeService;
    }

    // POST /api/recharges/user/1/plan/2
    @PostMapping("/user/{userId}/plan/{planId}")
    public ResponseEntity<Recharge> createRecharge(@PathVariable Long userId, @PathVariable Long planId) {
        Recharge recharge = rechargeService.createRecharge(userId, planId);
        return ResponseEntity.ok(recharge);
    }

    // GET /api/recharges/user/1
    @GetMapping("/user/{userId}")
    public ResponseEntity<List<RechargeDto>> getUserRecharges(@PathVariable Long userId) {
        Optional<Recharge> recharges = rechargeService.getRechargeHistory(userId);
        List<RechargeDto> result = recharges.stream()
                .map(r -> new RechargeDto(
                		r.getId(),
                        r.getUser().getName(),
                        r.getPlan().getName(),
                        r.getDate(),
                        r.getAmount(),
                        r.getStatus())).collect(Collectors.toList());
        return ResponseEntity.ok(result);
    }
    @GetMapping("/all")
    public ResponseEntity<List<Recharge>> getAllRecharges() {
        List<Recharge> allRecharges = rechargeService.getAllRecharges();
        return ResponseEntity.ok(allRecharges);
    }
    
}
