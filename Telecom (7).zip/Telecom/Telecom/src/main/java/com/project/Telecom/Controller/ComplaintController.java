package com.project.Telecom.Controller;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.project.Telecom.Dto.ComplaintDto;

import com.project.Telecom.Entity.Complaint;
import com.project.Telecom.Entity.ComplaintStatus;
import com.project.Telecom.Entity.User;
import com.project.Telecom.Repository.UserRepository;
import com.project.Telecom.Service.ComplaintService;
@RestController
@RequestMapping("/api/complaints")
public class ComplaintController {

    @Autowired
    private ComplaintService complaintService;

    @Autowired
    private UserRepository userRepository;

    // ✅ Authenticated user raises a complaint
    @PostMapping
    public ResponseEntity<?> raiseComplaint(@RequestBody ComplaintDto complaintDto,
                                            Authentication authentication) {
        try {
            Long userId = getUserIdFromAuth(authentication);
            complaintService.raiseComplaint(complaintDto, userId);
            return ResponseEntity.ok("Complaint raised successfully.");
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    // ✅ Authenticated user views their own complaints
    @GetMapping
    public ResponseEntity<List<ComplaintDto>> getUserComplaints(Authentication authentication) {
        Long userId = getUserIdFromAuth(authentication);
        List<ComplaintDto> complaints = complaintService.getUserComplaints(userId);
        return ResponseEntity.ok(complaints);
    }

    // ✅ Admin fetches all complaints
    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/admin")
    public ResponseEntity<List<ComplaintDto>> getAllComplaints() {
        List<ComplaintDto> complaints = complaintService.getAllComplaints();
        return ResponseEntity.ok(complaints);
    }

    // ✅ Admin updates complaint status
    @PreAuthorize("hasRole('ADMIN')")
    @PutMapping("/admin/{id}")
    public ResponseEntity<ComplaintDto> updateComplaintStatus(
            @PathVariable Long id,
            @RequestParam ComplaintStatus status) {

        ComplaintDto updatedComplaint = complaintService.updateComplaintStatus(id, status);
        return ResponseEntity.ok(updatedComplaint);
    }

    // ✅ Helper method to extract user ID from authentication
    private Long getUserIdFromAuth(Authentication authentication) {
        String email = authentication.getName(); // set by JWT after validation
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new UsernameNotFoundException("User not found"));
        return user.getId();
    }
}
