package com.project.Telecom.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.project.Telecom.Entity.Plan;

@Repository
@EnableJpaRepositories
public interface PlanRepository extends CrudRepository<Plan,Long>,JpaRepository<Plan,Long> {
//	@Query("SELECT c.title AS title, COUNT(c) AS count FROM Complaint c GROUP BY c.title ORDER BY count DESC")
//	List<Object[]> findTopComplaintTypes();

}
