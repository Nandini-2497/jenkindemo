package com.project.Telecom.Repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.project.Telecom.Entity.User;

@Repository
@EnableJpaRepositories
public interface UserRepository extends CrudRepository<User,Long>,JpaRepository<User,Long> {
	Optional<User> findByEmail(String email);
//	@Query("SELECT COUNT(u) FROM User u WHERE DATE(u.createdAt) = CURRENT_DATE")
//	long countTodayUsers();

	

}
