package com.project.Telecom.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.Telecom.Dto.ComplaintDto;
import com.project.Telecom.Entity.Complaint;
import com.project.Telecom.Entity.ComplaintStatus;
import com.project.Telecom.Entity.User;
import com.project.Telecom.Repository.ComplaintRepository;
import com.project.Telecom.Repository.UserRepository;

import jakarta.transaction.Transactional;


@Service
@Transactional
public class ComplaintService{

    @Autowired
    private ComplaintRepository complaintRepository;

    @Autowired
    private UserRepository userRepository;
    
        public void raiseComplaint(ComplaintDto complaintDto, Long id) throws RuntimeException{
            User user = userRepository.findById(id)
                    .orElseThrow(() -> new RuntimeException("User not found"));

            // Create and save complaint
            Complaint complaint = new Complaint();
            complaint.setTitle(complaintDto.getTitle());
            complaint.setDescription(complaintDto.getDescription());
            complaint.setComplaintStatus(ComplaintStatus.Open);
            complaint.setCreated_At(LocalDateTime.now());
            complaint.setResolved_At(complaintDto.getResolved_At());
            complaint.setUser(user);
            System.out.println(complaintDto);
            System.out.println(complaint);
            complaintRepository.save(complaint);
            
        }
        public List<ComplaintDto> getUserComplaints(Long userId) {
            User user = userRepository.findById(userId)
                    .orElseThrow(() -> new RuntimeException("User not found"));
            List<Complaint> complaints = complaintRepository.findByUser(user);
            return complaints.stream().map(this::mapToDto).collect(Collectors.toList());
        }

        // Admin: Get all complaints
        public List<ComplaintDto> getAllComplaints() {
            List<Complaint> complaints = complaintRepository.findAll();
            return complaints.stream().map(this::mapToDto).collect(Collectors.toList());
        }

        // Admin: Update complaint status
        public ComplaintDto updateComplaintStatus(Long complaintId, ComplaintStatus status) {
            Complaint complaint = complaintRepository.findById(complaintId)
                    .orElseThrow(() -> new RuntimeException("Complaint not found"));

            complaint.setComplaintStatus(status);

            if (status == ComplaintStatus.Resolved) {
                complaint.setResolved_At(LocalDateTime.now());
            } else {
                complaint.setResolved_At(null);
            }

            Complaint updatedComplaint = complaintRepository.save(complaint);
            return mapToDto(updatedComplaint);
        }

        // Utility to convert entity to DTO
        private ComplaintDto mapToDto(Complaint complaint) {
            ComplaintDto dto = new ComplaintDto();
            dto.setId(complaint.getId());
            dto.setTitle(complaint.getTitle());
            dto.setDescription(complaint.getDescription());
            dto.setComplaintStatus(complaint.getComplaintStatus());
            dto.setCreated_At(complaint.getCreated_At());
            dto.setResolved_At(complaint.getResolved_At());
            return dto;
        }
    }
  
		
    

	
