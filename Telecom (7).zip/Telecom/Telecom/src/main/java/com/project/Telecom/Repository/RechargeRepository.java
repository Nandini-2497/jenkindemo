package com.project.Telecom.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.stereotype.Repository;

import com.project.Telecom.Entity.Recharge;

@Repository
@EnableJpaRepositories
public interface RechargeRepository extends JpaRepository<Recharge,Long> {

//	List<Recharge> findByUserId(Long userId);
//	@Query("SELECT COUNT(r) FROM Recharge r WHERE DATE(r.rechargeDate) = CURRENT_DATE")
//	long countTodayRecharges();
//
//	@Query("SELECT SUM(r.amount) FROM Recharge r WHERE DATE(r.rechargeDate) = CURRENT_DATE")
//	Double sumTodayRevenue();
	
	

}
